// Filename HelloDialog.java
// Written by James Shoemaker
// Written on 8/21/26

import javax.swing.JOptionPane;
public class HelloDialog{
    public static void main(String[] args)
    {
        JOptionPane.showMessageDialog(null, "Hello, world!");
    }
}