// Filename hello2.java
// Written by James Shoemaker
// Written on 8/21/24

public class hello2
/* This class demonstrates the use of printIn()
method to print the message Hello, World! */
{
    public static void main(String[] args)
    {
        System.out.println("Hello, world!");
    }
}