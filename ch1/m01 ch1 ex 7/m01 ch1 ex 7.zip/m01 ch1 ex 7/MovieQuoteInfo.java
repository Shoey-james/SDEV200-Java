// MovieQuoteInfo.java
// James Shoemaker
// 8/24/26

public class MovieQuoteInfo
{
    public static void main(String[] args)
    {
        System.out.println("May the Force be with you - Star Wars 1977");
        System.out.println("I'll be back - Terminator 1984");
        System.out.println("There's no place like home - The Wizard of Oz 1939");
        System.out.println("You're gonna need a bigger boat - Jaws 1975");
    }
}